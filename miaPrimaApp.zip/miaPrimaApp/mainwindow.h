#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <string>


QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void onCaricaDatiClicked();
    void onCercaMatricolaClicked();
    void onCercaCognomeClicked();
    void onElencoStudentiClicked();
    void on_StampaEsami_clicked();
    void onNumeroStudentiClicked();
    void on_NumeroMaterie_clicked();
    void on_CercaMaterie_clicked();
    void on_InserisciStudente_clicked();
    void on_SalvaDati_clicked();
    void on_Esci_clicked();

    void on_Pulisci_clicked();



private:
    Ui::MainWindow *ui;
    std::string labels;  // per le etichette del csv
};

#endif // MAINWINDOW_H
