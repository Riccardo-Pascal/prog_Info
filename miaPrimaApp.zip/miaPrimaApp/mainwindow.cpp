#include "mainwindow.h"      // Definizione della classe MainWindow
#include "./ui_mainwindow.h" // Interfaccia grafica generata da Qt Designer
#include <iostream>         // Per eventuali debug con std::cout
#include <fstream>          // Per leggere file (ifstream)
#include <string>           // Per usare std::string
#include <QMessageBox>      // Per finestre di dialogo Qt (es. warning)
#include "tools.h"          // Per accedere a universita e funzioni
#include "strutture.h"      // Definizione strutture corso, materia, studente

map<corso, map<materia, vector<studente>>> universita;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this); // collega l'interfaccia grafica creata con Qt Designer (il file .ui) al codice C++.
    //senza ui non si vedrebbe l'interfaccia grafica
    //this sarebbe il mainWindow
    //ui->(qualcosa) si accedo ai widget disegnati sul .ui
    connect(ui->CaricaDati, &QPushButton::clicked, this, &MainWindow::onCaricaDatiClicked);
    connect(ui->CercaMatricola, &QPushButton::clicked, this, &MainWindow::onCercaMatricolaClicked);
    connect(ui->CercaCognome, &QPushButton::clicked, this, &MainWindow::onCercaCognomeClicked);
    connect(ui->ElencoStudenti, &QPushButton::clicked, this, &MainWindow::onElencoStudentiClicked);
    connect(ui->StampaEsami, &QPushButton::clicked, this, &MainWindow::on_StampaEsami_clicked);
    connect(ui->NumeroStudenti, &QPushButton::clicked, this, &MainWindow::onNumeroStudentiClicked);
    connect(ui->NumeroMaterie, &QPushButton::clicked, this, &MainWindow::on_NumeroMaterie_clicked);
    connect(ui->CercaMaterie, &QPushButton::clicked, this, &MainWindow::on_CercaMaterie_clicked);
    connect(ui->InserisciStudente, &QPushButton::clicked, this, &MainWindow::on_InserisciStudente_clicked);
    connect(ui->SalvaDati, &QPushButton::clicked, this, &MainWindow::on_SalvaDati_clicked);
    connect(ui->Esci, &QPushButton::clicked, this, &::MainWindow::on_Esci_clicked);
    connect(ui->Pulisci, &QPushButton::clicked, this, &::MainWindow::on_Pulisci_clicked);
}

MainWindow::~MainWindow()
{
    delete ui;  // qui si libera la memoria allocata con new Ui::MainWindow
}

void MainWindow::onCaricaDatiClicked() {
    ifstream fin("corsi_studenti.csv",ios::in);

    if (!fin.is_open()) {
        QMessageBox::warning(this, "Errore", "Impossibile aprire il file corsi_studenti.csv");
        return;// se non riesco ad aprire il file esco dalla funzione
    }
    //input labels
    getline(fin,labels);
    string codC,descrC,codM,descrM,mat,cognS,nomeS;
    int matS;
    while(getline(fin,codC,',')){

        //input codice_corso
        if (codC == "") break;
        //descrizione_corso
        getline(fin,descrC,',');
        corso c{codC,descrC};

        //codice_materia
        getline(fin,codM,',');
        //descrizione_materia
        getline(fin,descrM,',');
        materia s{codM,descrM,codC};

        //matricola_studente
        getline(fin,mat,',');
        matS = stoi(mat);
        //cognome_studente
        getline(fin,cognS,',');
        //nome_studente
        getline(fin,nomeS);
        studente p{matS,cognS,nomeS,codC};

        universita[c][s].push_back(p);

    }
    fin.close();

}

void MainWindow::onCercaMatricolaClicked() {
    QString inputMatricola = ui->lineEditMatricola->text();  // Legge la matricola dalla QLineEdit
    long int matricola = inputMatricola.toLong();            // Converte QString in long int
    // Chiama la funzione che cerca il corso della matricola
    string nomeCorso = matricolaPerCorso(matricola);

    QString descr = QString::fromStdString(nomeCorso); // Converte il risultato in QString per mostrarlo

    if (nomeCorso=="") {
        ui->labelRisultato->setText("Matricola non trovata");
    } else {
        ui->labelRisultato->setText("Corso trovato: " + descr);
    }

}
void MainWindow::onCercaCognomeClicked() {

    QString inputCogn = ui->lineEditCognome->text();

    string cogn = inputCogn.toStdString();

    // Chiama la funzione che cerca il corso del cognome
    string descr = cognomePerCorso(cogn);
    QString descrizione = QString::fromStdString(descr);

    if(descr == ""){
        ui->labelRisultato_2->setText("Cognome non trovato");
    }   else {
        ui->labelRisultato_2->setText("Corso trovato : " + descrizione);
    }
}

void MainWindow::onElencoStudentiClicked()  {

    QString inputCode = ui-> elencoStud ->text();

    string code = inputCode.toStdString();

    QString tuttiStudenti;
    for (auto& x : matricolaCorso(code)) {
        tuttiStudenti += QString::fromStdString(x.cogn) + "," +
                         QString::fromStdString(x.nome) + "," +
                         QString::number(x.matr) + "\n";
    }
    ui->labelRisultato_3->setText(tuttiStudenti);
}

void MainWindow::on_StampaEsami_clicked(){
    QString inputCode = ui->stampaEsami->text();
    string cod = inputCode.toStdString();

    map<vector<materia>, vector<studente>> esamiStudente;
    QString info;

    // Recupera la mappa materia → studenti per quel corso
    esamiPerCorso(cod, esamiStudente);

    for (auto& pair : esamiStudente) {
        for (auto& mat : pair.first) {
            for (auto& stud : pair.second) {
                info += QString::fromStdString(mat.cod_materia) + ", " +
                        QString::fromStdString(mat.descr_materia) + ", " +
                        QString::fromStdString(stud.cogn) + ", " +
                        QString::fromStdString(stud.nome) + ", " +
                        QString::number(stud.matr) + "\n";
            }
        }
    }

    if (info.isEmpty()) {
        ui->labelRisultato_4->setText("Nessun esame trovato per questo corso.");
    } else {
        ui->labelRisultato_4->setText(info);
    }

    esamiStudente.clear();
}

void MainWindow::onNumeroStudentiClicked(){
    QString inputCode = ui->studentiPerCorso->text();
    string cod = inputCode.toStdString();

    set<long int> matPerStudenti;

    int count = contaStudentiPerCorso(cod, matPerStudenti);

    // Mostra il risultato nella QLabel
    ui->labelRisultato_5->setText("Numero studenti: " + QString::number(count));

    matPerStudenti.clear();
}

void MainWindow::on_NumeroMaterie_clicked(){
    QString inputCode = ui->materiePerCorso->text();
    string cod = inputCode.toStdString();


    int count = materiePerCorso(cod);

    ui->labelRisultato_6->setText("Numero materie: " + QString::number(count));
}
void MainWindow::on_CercaMaterie_clicked()  {
    QString inputCode = ui->lineEditDescr->text();
    string descrMat = inputCode.toStdString();

    map<string,string> descrMateria;

    QString risultato;

    for (auto& materia : descrPerMateria(descrMat, descrMateria)) {
        risultato += QString::fromStdString(materia.second) + " - " + QString::fromStdString(materia.first) + "\n";
    }

    ui->labelRisultato_7->setText(risultato);
}
void MainWindow::on_InserisciStudente_clicked(){
    QString inputCogn = ui->Cogn->text();
    string cogn = inputCogn.toStdString();

    QString inputNome = ui->nome->text();
    string nome = inputNome.toStdString();

    QString inputMatr = ui->lineEditMatr->text();
    long int matr = inputMatr.toLong();

    QString inputMateria = ui->lineEditMateria->text();
    string materia = inputMateria.toStdString();

    inserimentoConMateria(matr,cogn,nome,materia);
}
void MainWindow::on_SalvaDati_clicked(){
    ofstream fout("corsi_studenti.csv");

    fout << labels <<endl;

    for (auto& corsoMateriaStudente : universita) {
        for (auto& materiaStudente : corsoMateriaStudente.second) {
            for (auto& studenti : materiaStudente.second) {
                fout << corsoMateriaStudente.first.cod_corso << ","
                     << corsoMateriaStudente.first.descr_corso << ","
                     << materiaStudente.first.cod_materia << ","
                     << materiaStudente.first.descr_materia << ","
                     << studenti.matr << ","
                     << studenti.cogn << ","
                     << studenti.nome <<endl;
            }
        }
    }
    fout.close();

    QMessageBox::information(this, "Successo", "Dati salvati correttamente nel file.");//per conferma all'utente
}

void MainWindow::on_Esci_clicked(){

    QApplication::quit();

}

void MainWindow::on_Pulisci_clicked(){
    ui->labelRisultato->clear();
    ui->labelRisultato_2->clear();
    ui->labelRisultato_3->clear();
    ui->labelRisultato_4->clear();
    ui->labelRisultato_5->clear();
    ui->labelRisultato_6->clear();
    ui->labelRisultato_7->clear();
}












